//
//  Movie.swift
//  Movie Browser
//
//  Created by Nikhil Muskur on 13/08/18.
//  Copyright © 2018 Nikhil Muskur. All rights reserved.
//

import Foundation

struct Movie: Hashable {

	var hashValue: Int {
		return movieID
	}
	
	static func ==(lhs: Movie, rhs: Movie) -> Bool {
		return lhs.movieID == rhs.movieID
	}
	
	var movieID: Int
	var title: String
	var posterURL: String
	var overview: String
	var rating: Double
	var releaseDate: Date
	var votesForRating: Int
	var movieLargePosterURL: String
}
