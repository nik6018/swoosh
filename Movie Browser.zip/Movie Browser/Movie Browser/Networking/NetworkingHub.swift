//
//  NetworkingHub.swift
//  Movie Browser
//
//  Created by Nikhil Muskur on 13/08/18.
//  Copyright © 2018 Nikhil Muskur. All rights reserved.
//

import Foundation

enum ParseResult {
	case success([Movie])
	case failure(Error)
}

class NetworkingHub {

	private var networkSession: URLSession = {
		let config = URLSessionConfiguration.default
		return URLSession(configuration: config)
	}()
	
	private var networkDataTask: URLSessionDataTask?
	
	private var dateFormatter: DateFormatter = {
		let formatter = DateFormatter()
		formatter.dateFormat = "yyyy-MM-dd"
		return formatter
	}()
	
	// function to fetch all the movies
	func fetchMovieList(
		withEndPoint endPoint: Endpoints,
		withParams params: [String: String],
		completion: @escaping ([Movie], String) -> Void) {
	
		// Get the URL for the Requested EndPoint
		if let requestURL = TMDb.getEndPointURL(fromEndPoint: endPoint, withParams: params) {
			
			// make the request
			networkDataTask = networkSession.dataTask(with: requestURL) { (data, response, error) in
				if let networkError = error {
					completion([], networkError.localizedDescription)
				}
				
				if let responseData = data {
					do {
						let jsonData = try JSONSerialization.jsonObject(
												with: responseData,
												options: [])
						
						let jsonObject = jsonData as! [AnyHashable: Any]
						print(jsonObject)
						let parseResult = self.parseJsonObjects(from: jsonObject)
						
						// check for any parse error
						switch parseResult {
						case .success(let movies):
							completion(movies, "")
						case .failure(let parseError):
							completion([], parseError.localizedDescription)
						}
					} catch {
						completion([], error.localizedDescription)
					}
				}
			}
			
			networkDataTask?.resume()
			
		} else {
			completion([], "Cannot Create the API URL for Request")
		}
	}
	
	//function to fetch the movie poster or image
	
	func fetchMoviePoster(
		withRelativePath path: String,
		withImageWidth width: String,
		completion: @escaping ((Data?, String) -> Void)) {
		
		//get the URL to fetch Image
		if let requestURL = TMDb.getAbsoluteImageURL(withPath: path, withImageWidth: width) {
			
			networkDataTask = networkSession.dataTask(with: requestURL){ (data, resposne, error) in
				
				if let networkError = error {
					DispatchQueue.main.async {
						completion(nil, networkError.localizedDescription)
					}
				}
				
				if let imageData = data {
					DispatchQueue.main.async {
						completion(imageData, "")
					}
				}
			}
			
			networkDataTask?.resume()
		}
	}
	
	func searchForMovie(
		withParams params: [String: String],
		completion: @escaping ([Movie], String, Int) -> Void) {
		
		var totalNumberOfPages = 0
		
		if let requestURL = TMDb.getEndPointURL(
									fromEndPoint: .search, withParams: params){
			
			networkDataTask = networkSession.dataTask(with: requestURL) { (data, response, error) in
				if let networkError = error {
					completion([], networkError.localizedDescription, totalNumberOfPages)
				}
				
				if let responseData = data {
					do {
						let jsonData = try JSONSerialization.jsonObject(
							with: responseData,
							options: [])
						
						let jsonObject = jsonData as! [AnyHashable: Any]
						print(jsonObject)
						let parseResult = self.parseJsonObjects(from: jsonObject)
						
						// check for any parse error
						switch parseResult {
						case .success(let movies):
							// can force unwrap here since the JSON is not corrupted.
							totalNumberOfPages = (jsonObject["total_pages"] as? Int)!
							completion(movies, "", totalNumberOfPages)
						case .failure(let parseError):
							completion([], parseError.localizedDescription, totalNumberOfPages)
						}
					} catch {
						completion([], error.localizedDescription, totalNumberOfPages)
					}
				}
			}
			
			networkDataTask?.resume()
		} else {
			completion([], "Cannot create the API URL", totalNumberOfPages)
		}
	}
	
	// MARK:- JSON Parse Functions
	
	private func parseJsonObjects(from jsonData: [AnyHashable: Any]) -> ParseResult {
		
		guard
		let movieObjects = jsonData["results"] as? [[String: Any]] else{
				return .failure("Cannot Parse the JSON" as! Error)
		}
		
		var movies = [Movie]()
		
		for rawMovieObjects in movieObjects {
			if let movie = pareseObject(rawMovieObjects) {
				movies.append(movie)
			}
		}
		
		return .success(movies)
	}
	
	private func pareseObject(_ movieObject: [String: Any]) -> Movie? {
		
		guard
			let id = movieObject["id"] as? Int,
			let title = movieObject["original_title"] as? String,
			let rating = movieObject["vote_average"] as? Double,
			let posterLink = movieObject["poster_path"] as? String,
			let overview = movieObject["overview"] as? String,
			let votes = movieObject["vote_count"] as? Int,
			let largePosterLink = movieObject["backdrop_path"] as? String,
			let releaseDate =  dateFormatter.date(
									from: movieObject["release_date"] as! String) else {
				return nil
		}
		
		return Movie(
			movieID: id,
			title: title,
			posterURL: posterLink,
			overview: overview,
			rating: rating,
			releaseDate: releaseDate,
			votesForRating: votes,
			movieLargePosterURL: largePosterLink)
	}
}





