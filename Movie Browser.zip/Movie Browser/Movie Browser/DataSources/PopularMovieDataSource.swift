//
//  PopularMovieDataSource.swift
//  Movie Browser
//
//  Created by Nikhil Muskur on 13/08/18.
//  Copyright © 2018 Nikhil Muskur. All rights reserved.
//

import UIKit

class PopularMovieDataSource: NSObject {
	
	

	
	func getMovieList(sortedBy sortType: SortType) {
		
		// call the n/w func here and fetch the data
		
		
		// update the array
		// reload the collectionView passed in the completion handler
		
	}
}

